
#include "define.h"
#include "genvars.h"
#include "utils.c"

SDL_Surface* init_SDL()
{
	/* initialize SDL */
	SDL_Init(SDL_INIT_VIDEO);

	/* set the title bar */
	SDL_WM_SetCaption(WIN_TITLE, WIN_TITLE);

	/* create window */
	SDL_Surface* screen = SDL_SetVideoMode(SCREEN_WIDTH,SCREEN_HEIGHT, 32, SDL_HWSURFACE);

	localEnv.screen = screen;
	return screen;	
}

void initGame() {
  SDL_Surface* frame = loadSprite("assets/arrplan.bmp");
  localEnv.frame = frame;
	
}
  
void arret()
{
    int cont = 1;
    SDL_Event event;
 
    while (cont)
    {
    SDL_FillRect(localEnv.screen, NULL, SDL_MapRGB(localEnv.screen->format, 255, 0, 0));
	
    SDL_Rect position;
    position.x = 0;
    position.y = 0;

    SDL_BlitSurface(localEnv.frame, NULL, localEnv.screen, &position);


    SDL_Flip(localEnv.screen);

    SDL_WaitEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
                cont = 0;
	case SDL_MOUSEBUTTONDOWN:
	  printf("X:%d, Y:%d\n", event.motion.x, event.motion.y);
        }
    }
}

int main(){
  init_SDL();
  initGame();
  arret ();
  SDL_FreeSurface(localEnv.frame);
  SDL_Quit();
 
  return 0;
}
