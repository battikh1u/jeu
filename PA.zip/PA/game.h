#include "define.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
/*typedef struct GeneralEnviroment
{
	SDL_Surface* screen;
	SDL_Surface* frame;
 } generalenviroment;
// STRUCT STORING ALL VARRIABLES
generalenviroment localEnv;
// function to init sdl
SDL_Surface* init_SDL();*/
