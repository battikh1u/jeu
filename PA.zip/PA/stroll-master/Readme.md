![](https://raw.githubusercontent.com/ssloy/stroll/master/screenshot.png)

This project is a stub for a small programming project, it shows how to start with SDL and Makefile.
The code contains a **very** crude and basic raytracer and is not meant to be used as is.

The textures are courtesy of André LaMothe and were initially distrubuted on
floppy discs with his excellent book "Tricks of the Game-Programming Gurus" published in 1994.
