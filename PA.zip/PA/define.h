#ifndef _DEFINE_H_
#define _DEFINE_H_
#include <SDL/SDL.h>
#include <stdio.h>
#include <stdlib.h>




#define SCREEN_WIDTH        799 // horizontal size of the frame
#define SCREEN_HEIGHT       501// vertical size of the frame
#define WIN_TITLE "MARIO_SIMPLE"


#endif
