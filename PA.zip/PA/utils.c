#include "genvars.h"
SDL_Surface* loadSprite(char path[50])
{
	/* load bitmap to temp surface */
	SDL_Surface* temp = SDL_LoadBMP(path);
//	printf("temp: %p\n",temp);


	/* convert bitmap to display format */
	SDL_Surface* sprt = SDL_DisplayFormat(temp);

//	printf("%p %p\n",temp, sprt);



	/* setup sprite colorkey and turn on RLE */
	int colorkey = SDL_MapRGB(localEnv.screen->format, 255, 0, 255);
	SDL_SetColorKey(sprt, SDL_SRCCOLORKEY | SDL_RLEACCEL, colorkey);

	/* free the temp surface */
	SDL_FreeSurface(temp);
	return sprt;
}
