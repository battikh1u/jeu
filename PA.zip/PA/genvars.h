#ifndef _GENVARS_H_
#define _GENVARS_H_
#include "define.h"
typedef struct GeneralEnv
{
	SDL_Surface* screen;
	SDL_Surface* frame;
} GeneralEnviroment;

GeneralEnviroment localEnv;

SDL_Surface* init_SDL();
void remove_SDL();
#endif
